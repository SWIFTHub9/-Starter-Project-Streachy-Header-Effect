//
//  TableViewController.swift
//  Streachy Header Effect Starter Project
//
//  Created by Abhishek Verma on 04/04/18.
//  Copyright © 2018 Abhishek Verma. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {

    var Data = [["Name":"How To Use Firebase Crashlytics In Swift 4 Xcode 9","Date":"5 Days.","TutorialImageName":"Crashlytics"],
                      ["Name":"How To Use Google Snackbar In Swift 4 Xcode 9 ","Date":"2 Days.","TutorialImageName":"Snackbar"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // Tableview Methods
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 272
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 10
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Data.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCell
        let IndexPath = Data[indexPath.row]
        cell.DateLabel.text = IndexPath["Date"]
        cell.TutorialName.text = IndexPath["Name"]
        cell.Profileimage.image = UIImage(named: IndexPath["TutorialImageName"]!)
        return cell
    }
}
